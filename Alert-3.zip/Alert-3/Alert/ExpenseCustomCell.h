//
//  LocationCustomCell.h
//  SpanPlan
//
//  Created by SPAN Technology on 8/31/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpenseCustomCell : UITableViewCell<UITextFieldDelegate>
{
    
}
@property (nonatomic,retain) IBOutlet UILabel *countLabel;

@property (nonatomic,retain) IBOutlet UITextField *priceText;
@property (nonatomic,retain) IBOutlet UITextField *qtyText;
@property (nonatomic,retain) IBOutlet UITextField *totalText;

@property (nonatomic, retain) IBOutlet UIButton *deleteButton;

@end
