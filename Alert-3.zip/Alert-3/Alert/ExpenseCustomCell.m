//
//  LocationCustomCell.m
//  SpanPlan
//
//  Created by SPAN Technology on 8/31/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ExpenseCustomCell.h"

@implementation ExpenseCustomCell

@synthesize countLabel,priceText,qtyText,totalText,deleteButton;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)awakeFromNib{
    [super awakeFromNib];
    //Init data
    self.priceText.text = @"0";
    self.qtyText.text = @"0";
    //
    self.priceText.delegate = self;
    self.qtyText.delegate = self;
    self.totalText.delegate = self;
    self.priceText.keyboardType = UIKeyboardTypeDecimalPad;
    self.qtyText.keyboardType = UIKeyboardTypeNumberPad;

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(priceTextChange)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:self.priceText];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(qtyTextChange)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:self.qtyText];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(totalTextChange)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:self.totalText];

}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    return YES;
}

- (void)priceTextChange{
    double price = [NSDecimalNumber decimalNumberWithString:self.priceText.text locale:[NSLocale currentLocale]].doubleValue;
    double qty = [NSDecimalNumber decimalNumberWithString:self.qtyText.text locale:[NSLocale currentLocale]].doubleValue;
    double result = price*qty;
    
    self.totalText.text = [NSString stringWithFormat:@"%.f",result];
}

- (void)qtyTextChange{
    double price = [NSDecimalNumber decimalNumberWithString:self.priceText.text locale:[NSLocale currentLocale]].doubleValue;
    double qty = [NSDecimalNumber decimalNumberWithString:self.qtyText.text locale:[NSLocale currentLocale]].doubleValue;
    double result = price*qty;
    
    self.totalText.text = [NSString stringWithFormat:@"%f",result];
}

- (void)totalTextChange{
    NSLog(@"textField : %@",self.totalText.text);
}

@end
