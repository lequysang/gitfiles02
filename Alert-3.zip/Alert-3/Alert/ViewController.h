//
//  ViewController.h
//  Alert
//
//  Created by Admin on 02/12/12.
//  Copyright (c) 2012 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>
{
    int productCount;
    NSMutableArray *addProductCount_MutableArray;
}
@property(nonatomic,retain) IBOutlet UIButton *addContactButton;

@property (nonatomic, retain) IBOutlet UITableView *add_TableView;
@property (strong,nonatomic)IBOutlet UIScrollView *Create_ScrollView;

-(IBAction)addProductBtn:(id)sender;
-(IBAction)deleteProduct_FromList:(id)sender;
-(IBAction)saveProduct_FromList:(id)sender;

@end
