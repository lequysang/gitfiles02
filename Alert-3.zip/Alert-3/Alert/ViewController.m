//
//  ViewController.m
//  Alert
//
//  Created by Admin on 02/12/12.
//  Copyright (c) 2012 Admin. All rights reserved.
//

#import "ViewController.h"
#import "ExpenseCustomCell.h"


#define RGB(r, g, b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]


@interface ViewController ()

@end

@implementation ViewController

@synthesize addContactButton,add_TableView,Create_ScrollView;
- (void)viewDidLoad
{
    
    
    addProductCount_MutableArray=[[NSMutableArray alloc] init];
    productCount = 0;
    [addProductCount_MutableArray addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:productCount]]];
    [add_TableView reloadData];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
        [cell setBackgroundColor:Nil];
        [cell setBackgroundColor:RGB(181, 181, 181)];
        [add_TableView setSeparatorColor:RGB(51, 51, 51)];
        [add_TableView setBackgroundColor:RGB(181, 181, 181)];
        
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
        int rows = [addProductCount_MutableArray count];
        int height = rows*90;
        add_TableView.frame = CGRectMake(1, 10, 300, height);
        
        
        addContactButton.frame = CGRectMake(43, (add_TableView.frame.origin.y)+(add_TableView.frame.size.height)+20, 29, 29);
        Create_ScrollView.contentSize = CGSizeMake(140,(add_TableView.frame.origin.y)+(add_TableView.frame.size.height)+200);
        
        return [addProductCount_MutableArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        static NSString *CellIdentifier = @"ExpenseCustomCell";
        
        ExpenseCustomCell *cell = (ExpenseCustomCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            
            NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"ExpenseCustomCell" owner:self options:nil];
            
            for (id currentObject in topLevelObjects){
                if ([currentObject isKindOfClass:[UITableViewCell class]]){
                    cell =  (ExpenseCustomCell *) currentObject;
                    break;
                }
            }
        }
        
    [cell.deleteButton setTag:indexPath.row];
    
    [cell.priceText setTag:1];
    [cell.qtyText setTag:2];
    [cell.totalText setTag:3];
    
    cell.priceText.delegate = self;
    cell.qtyText.delegate = self;
    
    cell.countLabel.text = [addProductCount_MutableArray objectAtIndex:indexPath.row];
    return cell;
        
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 90;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
        
        NSLog(@"didSelectRowAtIndexPath...%d",indexPath.row);
        
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"%d",textField.tag);
    
    if(textField.tag == 1 || textField.tag == 2)
    {
        for(UIView *view in textField.superview.subviews)
        {
            if(view.tag == 3)
            {
                UITextField *totalField = (UITextField *)view;
                [totalField setText:@"xxx"]; //Calculate total here and set it
                break;
            }
        }
    }
}
-(IBAction)addProductBtn:(id)sender
{
    
    productCount = productCount + 1;
    [addProductCount_MutableArray addObject:[NSString stringWithFormat:@"%@",[NSNumber numberWithInt:productCount]]];
    
    NSArray* paths = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:productCount inSection:0]];
    [self.add_TableView beginUpdates];
    [self.add_TableView insertRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationLeft];
    [self.add_TableView endUpdates];
}

-(IBAction)deleteProduct_FromList:(id)sender
{
    
    UIButton *button = (UIButton *)sender;
    CGRect buttonFrame = [button convertRect:button.bounds toView:self.add_TableView];
    NSIndexPath *indexPath = [self.add_TableView indexPathForRowAtPoint:buttonFrame.origin];
    
    [addProductCount_MutableArray removeObjectAtIndex:indexPath.row];
    productCount = productCount - 1;
    
    NSArray* paths = [NSArray arrayWithObject:[NSIndexPath indexPathForRow:indexPath.row inSection:0]];
    [self.add_TableView beginUpdates];
    [self.add_TableView deleteRowsAtIndexPaths:paths withRowAnimation:UITableViewRowAnimationRight];
    [self.add_TableView endUpdates];
    
}
-(IBAction)saveProduct_FromList:(id)sender
{
    
    NSLog(@"saveProduct_FromList...");
}
@end
