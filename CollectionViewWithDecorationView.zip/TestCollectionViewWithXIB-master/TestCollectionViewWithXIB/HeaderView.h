//
//  HeaderView.h
//  TestCollectionViewWithXIB
//
//  Created by Sang Quý Lê on 8/22/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TopCell.h"
@protocol HeaderViewDelegate

-(void) didSelectTopCell:(TopCell *)topCell atIndexPath:(NSIndexPath *)indexPath;


@end

@interface HeaderView : UICollectionReusableView<UICollectionViewDelegate,UICollectionViewDataSource>
@property(weak,nonatomic) id<HeaderViewDelegate> delegate;

@property (weak, nonatomic) IBOutlet UICollectionView *topCollectionView;

@end
