//
//  TopCell.h
//  TestCollectionViewWithXIB
//
//  Created by Sang Quý Lê on 8/22/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TopCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *cellLabel;

@end
