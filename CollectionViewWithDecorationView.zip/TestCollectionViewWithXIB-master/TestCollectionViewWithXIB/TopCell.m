//
//  TopCell.m
//  TestCollectionViewWithXIB
//
//  Created by Sang Quý Lê on 8/22/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "TopCell.h"

@implementation TopCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
