//
//  ViewController.h
//  TestCollectionViewWithXIB
//
//  Created by Quy Sang Le on 2/3/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCell.h"
#import "HeaderView.h"

@interface ViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource,HeaderViewDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
