//
//  TableCell.h
//  MyTableView
//
//  Created by Sang Quý Lê on 9/14/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableCell : UITableViewCell

@end
