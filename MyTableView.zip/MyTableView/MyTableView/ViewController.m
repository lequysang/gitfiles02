//
//  ViewController.m
//  MyTableView
//
//  Created by Sang Quý Lê on 9/14/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSArray *tableData;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self initData];
    [self initTableView];
    [self initBarItems];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)initData{
    self.tableData = [NSArray arrayWithObjects:
                      @"One",
                      @"Two",
                      @"Three",
                      @"Four",
                      @"Five",
                      @"Six",
                      nil];
}
- (void)initTableView{
    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    
    [self.tableView setSeparatorColor:[UIColor blueColor]];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
}
- (void)initBarItems{
    UIBarButtonItem *editBut = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editPress:)];
    self.navigationItem.leftBarButtonItem = editBut;
}
- (void)editPress:(UIBarButtonItem *)button{
    if (![self.tableView isEditing]) {
        [self.tableView setEditing:YES];
    } else {
        [self.tableView setEditing:NO];
    }
}
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableData.count;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    TableCell *cell = (TableCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[TableCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    // Configure the cell...
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.text = [self.tableData objectAtIndex:indexPath.row];
    if ((indexPath.row % 2) == 0) {
        cell.contentView.backgroundColor = [UIColor grayColor];
        cell.backgroundColor = [UIColor grayColor];
        cell.selectedBackgroundView.backgroundColor = [UIColor grayColor];
    }
    cell.imageView.image = [UIImage imageNamed:@"noteCon"];
    
    
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100.0;
}


@end
