//
//  LabelCell.h
//  RowInTableView
//
//  Created by Sang Quý Lê on 8/6/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LabelCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbOne;
@property (weak, nonatomic) IBOutlet UILabel *lbTwo;
@property (weak, nonatomic) IBOutlet UILabel *lbThree;

@end
