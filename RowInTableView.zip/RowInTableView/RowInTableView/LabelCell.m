//
//  LabelCell.m
//  RowInTableView
//
//  Created by Sang Quý Lê on 8/6/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "LabelCell.h"

@implementation LabelCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
