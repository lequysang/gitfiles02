//
//  ViewController.h
//  RowInTableView
//
//  Created by Sang Quý Lê on 8/6/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LabelCell.h"

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong,nonatomic) UITableView *tableView;

@end
