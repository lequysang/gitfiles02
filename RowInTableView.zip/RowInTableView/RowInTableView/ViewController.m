//
//  ViewController.m
//  RowInTableView
//
//  Created by Sang Quý Lê on 8/6/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) NSArray *tableData;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.tableData = [NSArray arrayWithObjects:
                      @"0",
                      @"1",
                      @"2",
                      @"3",
                      @"4",
                      @"5",
                      @"6",
                      @"7",
                      @"8",
                      @"9",
                      @"10",
//                      @"11",
//                      @"12",

                      nil];
    NSInteger numberOfRow = ceil(self.tableData.count%3);
    NSLog(@"Row %i",numberOfRow);
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.autoresizesSubviews = ( UIViewAutoresizingFlexibleWidth);
    [self.view addSubview:self.tableView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
//    return (self.tableData.count/3 + 1);
    return ceil(self.tableData.count/3.0);
}


// Customize the appearance of table view cells.
- (LabelCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"MYCELL";
    
    LabelCell *cell = (LabelCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"LabelCell" owner:nil options:nil] objectAtIndex:0];
    }
    
    // Configure the cell...
    if (indexPath.row < (ceil(self.tableData.count/3.0)-1)) {
        cell.lbOne.text = [self.tableData objectAtIndex:(indexPath.row*3)];
        cell.lbTwo.text = [self.tableData objectAtIndex:(indexPath.row*3+1)];
        cell.lbThree.text = [self.tableData objectAtIndex:(indexPath.row*3+2)];
    }
    
    // Config last row
    else{
        //Have 1 label
        if (ceil(self.tableData.count%3) == 1) {
            cell.lbOne.text = [self.tableData objectAtIndex:(indexPath.row*3)];
        }
        
        //Have 2 Label
        if (ceil(self.tableData.count%3) == 2) {
            cell.lbOne.text = [self.tableData objectAtIndex:(indexPath.row*3)];
            cell.lbTwo.text = [self.tableData objectAtIndex:(indexPath.row*3+1)];
        }
        
        //Have 3 Labels
        if (ceil(self.tableData.count%3) == 0) {
            cell.lbOne.text = [self.tableData objectAtIndex:(indexPath.row*3)];
            cell.lbTwo.text = [self.tableData objectAtIndex:(indexPath.row*3+1)];
            cell.lbThree.text = [self.tableData objectAtIndex:(indexPath.row*3+2)];
        }
        
    }
    


    
    return cell;
}


@end
