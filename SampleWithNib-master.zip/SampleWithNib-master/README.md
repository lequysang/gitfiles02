SampleWithNib
=============
