//
//  AppDelegate.h
//  Sample43
//
//  Created by admin on 8/27/13.
//  Copyright (c) 2013 walkmind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UIViewController *viewController;

@end
