//
//  EmbeddedViewController.h
//  Sample43
//
//  Created by admin on 8/29/13.
//  Copyright (c) 2013 walkmind. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmbeddedViewController : UIViewController

@end
