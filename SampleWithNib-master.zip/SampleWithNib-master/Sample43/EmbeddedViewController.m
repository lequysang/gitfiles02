//
//  EmbeddedViewController.m
//  Sample43
//
//  Created by admin on 8/29/13.
//  Copyright (c) 2013 walkmind. All rights reserved.
//

#import "EmbeddedViewController.h"

@interface EmbeddedViewController ()

@end

@implementation EmbeddedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
