//
//  AppDelegate.h
//  TableCoreData
//
//  Created by Sang Quý Lê on 7/21/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

#import "MMDrawerController.h"
#import "MMDrawerVisualState.h"
#import "MMExampleDrawerVisualStateManager.h"

#import "LeftPanelViewController.h"
//CenterView
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) MMDrawerController *drawerController;

@property (strong, nonatomic) UINavigationController *navigationController;

@property (strong, nonatomic) LeftPanelViewController *leftVC;

@property (strong, nonatomic) ViewController *centerVC;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@end
