//
//  ViewController.m
//  telextouch
//
//  Created by Sang Quý Lê on 7/18/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController


- (void)dumpFontNames{
    for (NSString *familyName in [UIFont familyNames]) {
        for (NSString *fontName in [UIFont fontNamesForFamilyName:familyName]) {
            if ([familyName hasPrefix:@"V"]
                ) {
                NSLog(@"%@ | %@",familyName, fontName);
            }
        }
    }
 
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
//    [self dumpFontNames];
    [self setupLeftMenuButton];
    [self setupToolbar];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload{
    NSLog(@"viewDidUnload");
}

- (void)viewWillDisappear:(BOOL)animated{
//    [self insertTextViewName:@"newBook" andText:self.textView.text];
}

#pragma mark setupToolbar
-(void)setupToolbar{
    UIColor *navBGColor = [UIColor colorWithRed:104/255.f green:73/255.f blue:44/255.f alpha:0.70f];
    
    [self.navigationController.navigationBar setTintColor:navBGColor];

}


-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

#pragma mark - Button Handlers
-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

-(void)rightDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

-(void)doubleTap:(UITapGestureRecognizer*)gesture{
    [self.mm_drawerController bouncePreviewForDrawerSide:MMDrawerSideLeft completion:nil];
}

-(void)twoFingerDoubleTap:(UITapGestureRecognizer*)gesture{
    [self.mm_drawerController bouncePreviewForDrawerSide:MMDrawerSideRight completion:nil];
}



@end
