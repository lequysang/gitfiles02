//
//  ViewController.m
//  TestListFont
//
//  Created by Sang Quý Lê on 12/9/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self dumpCustomFonts];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dumpCustomFonts{
    NSArray *iOSFontsArray = [NSArray arrayWithContentsOfFile:
                              [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:
                               @"AllFont.plist"]];
    NSMutableArray *fontFamilies = (NSMutableArray *)[UIFont familyNames];
    [fontFamilies removeObjectsInArray:iOSFontsArray];
    NSLog(@"%@",fontFamilies);
}

@end
