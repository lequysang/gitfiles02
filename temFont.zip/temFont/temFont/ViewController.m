//
//  ViewController.m
//  temFont
//
//  Created by Sang Quý Lê on 12/9/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self writeAlliOSFontsToPlist];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)writeAlliOSFontsToPlist{
    NSArray *fontFamilies = [UIFont familyNames];
    [self savePlist:@"AllFont" fromArray:fontFamilies];
}

#pragma mark - plist
- (NSString *) getFilePathForPlist:(NSString *) plistName {
    // placeholder
    NSArray *pathArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return [[pathArray objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist",plistName]];
}

-(void) savePlist:(NSString *)plistName fromArray:(NSArray *)array {
    [array writeToFile:[self getFilePathForPlist:plistName] atomically:YES];
}

- (NSMutableArray *) loadDataFromPlistToArray:(NSString *)plistName {
    NSString *plistPath = [self getFilePathForPlist:plistName];
    NSMutableArray *dataArray = [[NSMutableArray alloc] init];
    if ([[NSFileManager defaultManager] fileExistsAtPath:plistPath]) {
        dataArray = [NSMutableArray arrayWithContentsOfFile:plistPath];
    }
    return dataArray;
}


@end
